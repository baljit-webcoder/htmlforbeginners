# 📁 Media Folder

In this folder, you will store all your **images**, **videos**, and **audios** for your HTML exercises.

> 🗑️ You may delete this folder if you want, after reading.

---

## 🙏 THANK YOU!

Please consider supporting me by visiting my other GitHub projects.  
You can help by opening issues or making pull requests at:

🔗 [https://www.github.com/baljit-webcoder](https://www.github.com/baljit-webcoder)

---

### 💬 Final Words

> Thank you for your time and support 💙

---

## 📜 License

This whole collection is licensed under the  
[GNU General Public License (GPL) v3](https://www.gnu.org/licenses/gpl-3.0.en.html)

---

© Baljit Panda 2025 • [baljitpanda.rf.gd](https://baljitpanda.rf.gd)
